var app = angular.module('FirstApp', [
	'ui.router',
	'Dashboard',
	'Count'
])

.config(['$stateProvider', '$urlRouterProvider', function($stateProvider, $urlRouterProvider){

	//Setup redirects or default paths
	$urlRouterProvider.when('', '/start');

	//Define states of application
	$stateProvider
	.state('dashboard', {
		'abstract': true,
		'views': {
			'container': {
				'templateUrl': 'app/modules/dashboard/views/view-dashboard-container.html'
			},
			'nav@dashboard': {
				'templateUrl': 'app/modules/dashboard/views/view-dashboard-nav.html',
				'controller': 'NavController'
			}
		}
	})
	.state('dashboard.start', {
		'url': '/start',
		'views': {
			'header@dashboard': {
				'templateUrl': 'app/modules/dashboard/views/view-dashboard-header.html',
				'controller': 'HeaderController'
			},
			'main@dashboard': {
				'template': 'Click <code>Counter</code> in nav on left to test out routing.'
			}
		}
	})
	.state('dashboard.count', {
		'url': '/count',
		'views': {
			'header@dashboard': {
				'templateUrl': 'app/modules/dashboard/views/view-dashboard-header.html',
				'controller': 'HeaderController'
			},
			'main@dashboard': {
				'templateUrl': 'app/modules/count/views/view-count.html'
			}
		}
	});
}]);